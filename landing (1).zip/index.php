<?php
$api = [
    'key' => '13684',
    'secret' => 'kFxoKFVzDZF8ObYnnpcnvWJWIR2bOcEK',
    'flow_url' => 'https://leadrock.com/URL-XXXXX-XXXXX'
];

function send_the_order($post, $api)
{
    $params = [
        'flow_url' => $api['flow_url'],
        'user_phone' => $post['phone'],
        'user_name' => $post['name'],
        'other' => $post['other'],
        'ip' => $_SERVER['REMOTE_ADDR'],
        'ua' => $_SERVER['HTTP_USER_AGENT'],
        'api_key' => $api['key'],
        'sub1' => $post['sub1'],
        'sub2' => $post['sub2'],
        'sub3' => $post['sub3'],
        'sub4' => $post['sub4'],
        'sub5' => $post['sub5'],
        'ajax' => 1,
    ];
    $url = 'https://leadrock.com/api/v2/lead/save';

    $trackUrl = $params['flow_url'] . (strpos($params['flow_url'], '?') === false ? '?' : '&') . http_build_query($params);
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $trackUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
    $params['track_id'] = curl_exec($ch);

    $params['sign'] = sha1(http_build_query($params) . $api['secret']);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
    curl_exec($ch);
    curl_close($ch);

    header('Location: ' . (empty($post['success_page']) ? 'confirm.html' : $post['success_page']));
}

if (!empty($_POST['phone'])) {
    send_the_order($_REQUEST, $api);
}

if (!empty($_GET)) {
?>
    <script type="text/javascript">
        window.onload = function() {
            let forms = document.getElementsByTagName("form");
            for(let i=0; i<form action="index.php" s.length; i++) {
                let form = forms[i];
                form.setAttribute('action', form.getAttribute('action') + "?<?php echo http_build_query($_GET)?>");
                form.setAttribute('method', 'post');
            }
        };
    </script>
<?php
}

?>
<!DOCTYPE html><html lang="en"><head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=480">
	<title>Revitaprost Up Booster</title>
	<link rel="stylesheet" href="css/normalize.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" href="css/slick.css">
	<script>
		function dtime_nums(d, like_eu) {
		var now = new Date();
		now.setDate(now.getDate() + d + 1);
	  	
	  	var dayNum = '';
	  	if (now.getDate() < 10) {
	      	dayNum = '0';
	    }
	  	dayNum += now.getDate();
	  
	  	var monthNum = '';
		if (now.getMonth() + 1 < 10) {
	      	monthNum = '0';
	    }
	  	monthNum += now.getMonth() + 1;
	  	
	  	if (like_eu === true) {
			document.write(dayNum + "." + monthNum + "." + now.getFullYear());
	    } else {
			document.write(monthNum + "." + dayNum + "." + now.getFullYear());      
	    }

		}
	</script>
</head>
<body>
	<header class="header">
		<div class="header__top">
			<h1 class="header__heading h1"> Revitaprost Up Booster </h1>
			<p class="header__subheading lead"> Medicamento de nueva generación para la salud masculina</p>
			<ul class="header__list">
				<li class="header__item lead"> Aumenta la potencia</li>
				<li class="header__item lead"> Completamente seguro</li>
				<li class="header__item lead"> El sexo dura hasta 4 horas</li>
			</ul>

			<div class="header__price price">		
				<p class="price__header"> Liquidación final</p>
				<div class="price__wrapper">
					<div class="price__block price__block--old">
						<p class="price__text lead"> Precio anterior</p>
						<p class="price__price price__price--old"> 78<span class="price__currency">€</span></p>
					</div>
					<div class="price__block price__block--new">
						<p class="price__text lead"> Precio actual</p>
						<p class="price__price price__price--new"> 39<span class="price__currency">€</span></p>
					</div>
				</div>
				<div class="price__img-block">
					<img src="img/product.png" alt class="price__prod-img">
					<p class="price__label"> Descuento<span class="price__label--big"> 50%</span></p>
				</div>
			</div>
		</div>	
		<button class="header__btn scrollbtn btn"> Pedir</button>			
	</header>
	<main>
		<section class="intro">
			<h2 class="intro__heading h2"> Revitaprost Up Booster.<br> Para que la vida continúe. </h2>
			<div class="intro__img-block">
				<img src="img/intro-bg.jpg" alt class="intro__photo">
				<img src="img/product.png" alt class="intro__prod">
			</div>
			<div class="wrapper">
				<p class="intro__text lead"> El medicamento de manera integra actúa sobre el organismo masculina, eliminando las causas de la impotencia y no sus síntomas.</p>
				<p class="intro__text text"> A diferencia de sus predecesores, no provoca un daño el sistema cardiovascular, nervioso o sistema endocrino.</p>
			</div>			
		</section>

		<section class="problems">
			<div class="wrapper">
				<h2 class="problems__heading h2"> 5 problemas, 1 solución</h2>
				<ul class="problems__list">
					<li class="problems__item big"> Ausencia o debilidad en la potencia</li>
					<li class="problems__item big"> Eyaculación precoz </li>
					<li class="problems__item big"> Reducción de la libido</li>
					<li class="problems__item big"> Pérdida de la sensibilidad</li>
					<li class="problems__item big"> Prostatitis</li>
				</ul>
			</div>
			<div class="problems__wrapper">
				<p class="problems__text big"> ¡No es una sentencia final! ¡Revitaprost Up Booster te ayudará! </p>
				<img src="img/product.png" alt class="problems__img">
			</div>
		</section>

		<section class="offer"> 
			<div class="offer__top">
				<div class="wrapper">
					<h2 class="offer__heading h2"> Revitaprost Up Booster</h2>
					<p class="offer__subheading lead"> ¡Te regresará una vida plena!</p>
					<ul class="offer__list">
						<li class="offer__item lead"> Felicidad por el sexo</li>
						<li class="offer__item lead"> Fuerza masculina</li>
						<li class="offer__item lead"> Fuerte salud</li>
					</ul>
				</div>	
			</div>			
			<div class="price offer__price">		
				<p class="price__header"> Liquidación final</p>
				<div class="price__wrapper">
					<div class="price__block price__block--old">
						<p class="price__text lead"> Precio anterior</p>
						<p class="price__price price__price--old"> 78<span class="price__currency">€</span></p>
					</div>
					<div class="price__block price__block--new">
						<p class="price__text lead"> Precio actual</p>
						<p class="price__price price__price--new"> 39<span class="price__currency">€</span></p>
					</div>
				</div>
				<div class="price__img-block">
					<img src="img/product.png" alt class="price__prod-img">
					<p class="price__label"> Descuento<span class="price__label--big"> 50%</span></p>
				</div>
			</div>	
			<div class="wrapper">
				<ul class="timer">
					<li class="timer__item">
						<span class="timer__item--hour"></span>
						<p class="timer__item-text"> horas</p>
					</li>
					<li class="timer__dots">: </li>
					<li class="timer__item">
						<span class="timer__item--minutes"></span>
						<p class="timer__item-text"> minutos</p>
					</li>
					<li class="timer__dots">: </li>
					<li class="timer__item">
						<span class="timer__item--seconds"></span>
						<p class="timer__item-text"> segundos</p>
					</li>
				</ul>

				<button class="header__btn scrollbtn btn"> Pedir</button>	
			</div>
		</section>

		<section class="expert">
			<h2 class="expert__headnig h2"> Revitaprost Up Booster</h2>
			<img src="img/expert-photo.jpg" alt class="expert__photo">
			<div class="expert__name-block">
				<div class="wrapper">
					<p class="expert__name big"> David González</p>
					<p class="expert__position"> PhD. Andrólogo de alta categoría</p>
				</div>
			</div>
			<div class="wrapper">
				<p class="expert__text text"> "Me dedico a las cuestiones sexuales masculinas desde hace más de 35 años. Y yo sinceramente estoy contento de que productos como Revitaprost Up Booster estén apareciendo en el mercado. Gracias a él, miles de hombres han podido regresar a tener una vida sexual activa. Como doctor, me complace el hecho de que este medicamento restaura el cuerpo en su totalidad. ¡Sin duda, es una victoria para la ciencia!"</p>
			</div>
		</section>

		<section class="how">
			<div class="how__top">
				<div class="wrapper">
					<h2 class="how__heading h2"> ¿Cómo actúa Revitaprost Up Booster?</h2>

					<ul class="how__list">
						<li class="how__item how__item--1 lead"> Restaura el balance hormonal</li>
						<li class="how__item how__item--2  lead"> Alivia la inflamación de la próstata </li>
						<li class="how__item how__item--3 lead"> Normaliza las reacciones neurolépticas</li>
						<li class="how__item how__item--4 lead"> Aumenta la potencia</li>
						<li class="how__item how__item--5 lead"> ¡Regresa la salud y fuerza masculina!</li>
					</ul>
				</div>
			</div>

			<div class="how__bot">
				<div class="wrapper">
					<div class="how__mark-wrapper">
						<img src="img/mark-1.png" alt class="how__mark">
						<img src="img/mark-2.png" alt class="how__mark">
					</div>
					<div class="how__text-wrapper">
						<p class="how__text lead"> El medicamento es 100% natural. En su composición entran biocomponentes activos de origen vegetal.</p>
						<img src="img/product.png" alt class="how__prod">
					</div>
				</div>
			</div>
		</section>

		<section class="review">
			<div class="wrapper">
				<h2 class="review__heading h2"> Comentarios reales de Revitaprost Up Booster</h2>
				<div class="review__slider">
					<div class="review__slider-item">

						<div class="review__slider-top">
							<div class="review__slider-top-wrapper">
								<img src="img/top-ava.jpg" alt class="review__top-ava">
								<div class="review__top-comment">
									<p class="review__comment-text"> ¡Hola! Por favor, compartan sus comentarios sobre Revitaprost Up Booster. </p>
									<span class="review__top-comment-name review__top-comment-name--top"> Sunshine</span>
									<span class="review__top-comment-date">
										<script type="text/javascript">dtime_nums(-14,true)</script>
										14:22
									</span>
								</div>	
							</div>
							<span class="review__top-comment-name"> Sunshine</span>
						</div>

						<div class="review__comment-wrapper">

							<div class="review__comment-item">
								<div class="review__comment-head">
									<img class="review__com-ava" src="img/ava-1.jpg">
									<div class="review__comment-data">
										<p class="review__comment-name"> Carlos</p>
										<span class="review__comment-reg"> Registrado en el sitio desde 2018</span>
										<p class="review__comment-status"> En línea por última vez: hace menos de una hora</p>
									</div>
								</div>
								<p class="review__comment-text"> Por recomendaciones de mi doctor llevo tomando el tercer tratamiento. Me siento muy bien, no pienso dejarlo, ya que lo considero un soporte general para el cuerpo. Mi sensibilidad aumentó durante el sexo, no se, si solo a mí me pasó esto o a todos. </p>
							</div>

							<div class="review__comment-item">
								<div class="review__comment-head">									
									<img class="review__com-ava" src="img/ava-2.jpg">
									<div class="review__comment-data">
										<p class="review__comment-name"> Pablo</p>
										<span class="review__comment-reg"> Registrado en el sitio desde 2016</span>
										<p class="review__comment-status"> En línea por última vez: hace 5 horas</p>
									</div>
								</div>
								<p class="review__comment-text"> Mis problemas de potencia empezaron por el estrés, antes tardaba tiempo en terminar, pero después todo se fue aflojando. Aún soy joven, no tengo ni 40 años. Mi esposa y yo acudimos con un especialista y el me recomendó  Revitaprost Up Booster. ¡Ahora voy con el segundo tratamiento y siento que mi fuerza masculina ha regresado!</p>
							</div>

						</div>	
					</div>

					<div class="review__slider-item">

						<div class="review__slider-top">
							<div class="review__slider-top-wrapper">
								<img src="img/top-ava.jpg" alt class="review__top-ava">
								<div class="review__top-comment">
									<p class="review__comment-text"> ¡Hola! Por favor, compartan sus comentarios sobre Revitaprost Up Booster. </p>
									<span class="review__top-comment-name review__top-comment-name--top"> Sunshine</span>
									<span class="review__top-comment-date">
										<script type="text/javascript">dtime_nums(-14,true)</script>
										14:22
									</span>
									</div>
								</div>
								<span class="review__top-comment-name"> Sunshine</span>
						</div>

						<div class="review__comment-wrapper">

							<div class="review__comment-item">
								<div class="review__comment-head">
									<img class="review__com-ava" src="img/ava-3.jpg">
									<div class="review__comment-data">
										<p class="review__comment-name"> Martín</p>
										<span class="review__comment-reg"> Registrado en el sitio desde 2018</span>
										<p class="review__comment-status"> En línea por última vez: hace menos de una hora</p>
									</div>
								</div>
								<p class="review__comment-text"> Me gusta que no lo tengo que tomar antes del sexo. En la mañana lo tomé y por la tarde ya lo había olvidado. Y en general es mucho mejor que el viagra, ya que es más seguro.</p>
							</div>

							<div class="review__comment-item">
								<div class="review__comment-head">									
									<img class="review__com-ava" src="img/ava-4.jpg">
									<div class="review__comment-data">
										<p class="review__comment-name"> Daniel</p>
										<span class="review__comment-reg"> Registrado en el sitio desde 2014</span>
										<p class="review__comment-status"> En línea por última vez: hace 10 horas</p>
									</div>
								</div>
								<p class="review__comment-text"> Directo al grano: lo tengo parado por mucho tiempo y con firmeza. Mi esposa está feliz. Yo también.</p>
							</div>

						</div>	
					</div>

					<div class="review__slider-item">

						<div class="review__slider-top">
							<div class="review__slider-top-wrapper">
								<img src="img/top-ava.jpg" alt class="review__top-ava">
								<div class="review__top-comment">
									<p class="review__comment-text"> ¡Hola! Por favor, compartan sus comentarios sobre Revitaprost Up Booster. </p>
									<span class="review__top-comment-name review__top-comment-name--top"> Sunshine</span>
									<span class="review__top-comment-date">
										<script type="text/javascript">dtime_nums(-14,true)</script>
										14:22
									</span>
								</div>
							</div>
							<span class="review__top-comment-name"> Sunshine</span>
						</div>

						<div class="review__comment-wrapper">

							<div class="review__comment-item">
								<div class="review__comment-head">
									<img class="review__com-ava" src="img/ava-5.jpg">
									<div class="review__comment-data">
										<p class="review__comment-name"> Tomas</p>
										<span class="review__comment-reg"> Registrado en el sitio desde 2015</span>
										<p class="review__comment-status"> En línea por última vez: hace 2 días</p>
									</div>
								</div>
								<p class="review__comment-text"> Tengo 72 años y aún estoy en forma gracias a Revitaprost Up Booster. Lo recomiendo, este medicamento ha sido probado y es confiable. Lo importante es tomarlo por la mañana. Pero para las personas de mi edad, esto no es un problema, ya que tengo que tomar varias pastillas. Por cierto, a quien le interese saber: Revitaprost Up Booster puede tomarse con otros medicamentos. </p>
							</div>

							<div class="review__comment-item">
								<div class="review__comment-head">									
									<img class="review__com-ava" src="img/ava-6.jpg">
									<div class="review__comment-data">
										<p class="review__comment-name"> Sandro</p>
										<span class="review__comment-reg"> Registrado en el sitio desde 2015</span>
										<p class="review__comment-status"> En línea por última vez: hace 10 días</p>
									</div>
								</div>
								<p class="review__comment-text"> 100% satisfecho. La erección siempre llega cuando la necesito.</p>
							</div>
						</div>	
					</div>

					<div class="review__slider-item">
						<div class="review__slider-top">
							<div class="review__slider-top-wrapper">
								<img src="img/top-ava.jpg" alt class="review__top-ava">
								<div class="review__top-comment">
									<p class="review__comment-text"> ¡Hola! Por favor, compartan sus comentarios sobre Revitaprost Up Booster. </p>
									<span class="review__top-comment-name review__top-comment-name--top"> Sunshine</span>
									<span class="review__top-comment-date">
										<script type="text/javascript">dtime_nums(-14,true)</script>
										14:22
									</span>
									</div>
								</div>
								<span class="review__top-comment-name"> Sunshine</span>
						</div>
						<div class="review__comment-wrapper">
							<div class="review__comment-item">
								<div class="review__comment-head">
									<img class="review__com-ava" src="img/ava-7.jpg">
									<div class="review__comment-data">
										<p class="review__comment-name"> Joaquín</p>
										<span class="review__comment-reg"> Registrado en el sitio desde 2018</span>
										<p class="review__comment-status"> En línea por última vez: hace menos de una hora</p>
									</div>
								</div>
								<p class="review__comment-text"> La medicina es realmente sorprendente. Hace unos años, le dije adiós a la vida sexual porque no podía tomar viagra por mi corazón. ¡Pero apareció Revitaprost Up Booster y estoy de vuelta en el ruedo! </p>
							</div>

							<div class="review__comment-item">
								<div class="review__comment-head">									
									<img class="review__com-ava" src="img/ava-8.jpg">
									<div class="review__comment-data">
										<p class="review__comment-name"> Hernán</p>
										<span class="review__comment-reg"> Registrado en el sitio desde 2010</span>
										<p class="review__comment-status"> En línea por última vez: hace 5 días</p>
									</div>
								</div>
								<p class="review__comment-text"> Es un excelente medicamento, lo tomo por recomendación de mi médico. No tiene efectos secundarios. Los recomiendo encarecidamente. </p>
							</div>
						</div>	
					</div>

				</div>
			</div>
		</section>

		<section class="order">
			<div class="wrapper">
				<h2 class="order__heading h2"> Pide Revitaprost Up Booster en la tienda oficial</h2>
				<ul class="order__list">
					<li class="order__item order__item--req big"> Deja una solicitud en el sitio web</li>
					<li class="order__item big order__item--call"> Espera la llamada de un ejecutivo</li>
					<li class="order__item big order__item--pay"> Paga el producto al recibirlo</li>
				</ul>
			</div>
		</section>	

		<section class="header header--form">
			<div class="header__top header__top--form">
				<h1 class="header__heading h1"> Revitaprost Up Booster </h1>
				<p class="header__subheading lead"> Medicamento de nueva generación para la salud masculina</p>
				<ul class="header__list">
					<li class="header__item lead"> Felicidad por el sexo</li>
					<li class="header__item lead"> Fuerza masculina</li>
					<li class="header__item lead"> Fuerte salud</li>
				</ul>
				
				<div class="header__price price">		
					<p class="price__header"> Liquidación final</p>
					<div class="price__wrapper">
						<div class="price__block price__block--old">
							<p class="price__text lead"> Precio anterior</p>
							<p class="price__price price__price--old"> 78<span class="price__currency">€</span></p>
						</div>
						<div class="price__block price__block--new">
							<p class="price__text lead"> Precio actual</p>
							<p class="price__price price__price--new"> 39<span class="price__currency">€</span></p>
						</div>
					</div>
					<div class="price__img-block">
						<img src="img/product.png" alt class="price__prod-img">
						<p class="price__label"> Descuento<span class="price__label--big"> 50%</span></p>
					</div>
				</div>
			</div>	
			<div class="wrapper">
				<form action="index.php"  action class="form" method="post">
					<p class="form__heading big"> Rellena el formulario y obtén un descuento</p>

					<label for class="form__label lead"> Ejemplo: Ángel López</label>
					<input name="name" type="text" class="form__input lead" required placeholder="Nombre">
					<label for class="form__label lead"> Ejemplo: +34 961974686</label>
					<input name="phone" type="tel" class="form__input lead" required placeholder="Tu número de teléfono">
					<ul class="timer">
						<li class="timer__item">
							<span class="timer__item--hour"></span>
							<p class="timer__item-text"> horas</p>
						</li>
						<li class="timer__dots">: </li>
						<li class="timer__item">
							<span class="timer__item--minutes"></span>
							<p class="timer__item-text"> minutos</p>
						</li>
						<li class="timer__dots">: </li>
						<li class="timer__item">
							<span class="timer__item--seconds"></span>
							<p class="timer__item-text"> segundos</p>
						</li>
					</ul>
					<button type="submit" class="form__btn btn"> Pedir con descuento</button>
				<input type="hidden" name="sub1" value="{subid}">
</form>	
				<img src="img/secure.png" alt class="header__secure">
			</div>
	</section>	
	</main>

	<footer>
		<div class="wrapper">
			<p class="footer__text text"> Trestadar INC, 720 Oak Drive, Carlock, IL 61725, USA</p>
			<a target="_blank" href="policy_es.html" class="footer__link"> Política de confidencialidad</a>
		</div>
	</footer>


	<script src="js/jquery-3.4.1.min.js"></script>
	<script src="js/slick.min.js"></script>
	<script src="js/scripts.js"></script>

<!--CB-->
	<div class="feedback">
		<img src="img/i-phone.png" alt="">
	</div>
	<div class="popup-window">
		<div class="close-popup"></div>
		<form action="index.php"  method="POST" >
			<label for="name2">Por ejemplo:  Ángel López</label>
			<input id="name2" type="text" name="name" placeholder="Ingrese su nombre" required>
			<label for="phone2">Por ejemplo: +34 933 543 342</label>
			<input id="phone2" type="tel" name="phone" placeholder="Ingrese su numero de telefono" required>
			<button type="submit">Pedir</button>
		<input type="hidden" name="sub1" value="{subid}">
</form>
	</div>

	<style>
		.feedback {
			width: 75px;
			height: 70px;
			position: fixed;
			right: -15px;
			top: 15%;
			display: flex;
			align-items: center;
			background-color: #F42362;;
			padding-left: 10px;
			border-top-left-radius: 35px;
			border-bottom-left-radius: 35px;
			cursor: pointer;
			z-index: 1000;
			box-shadow: 0px 0px 1px rgba(0, 0, 0, 0.3);
			transition: all .5s;
		}

		.feedback:hover {
			right: 0;
		}

		.feedback img {
			width: 50px;
			height: 50px;
		}

		.popup-window {
			font-family: inherit;
			display: none;
			width: 300px;
			position: fixed;
			right: 0;
			top: 15%;
			padding: 35px 10px;
			background: #fff;
			border-radius: 5px;
			z-index: 2000;
		}

		.popup-window form {
			width: 100%;
			min-height: auto;
			padding: 0;
			background: inherit;
			box-shadow: none;
		}

		.popup-window label {
			display: block;
			margin-bottom: 5px;
			font-size: 14px;
			color: #333;
			text-transform: uppercase;
		}

		.popup-window input {
			box-sizing: border-box;
			width: 100%;
			height: auto;
			margin-bottom: 10px;
			padding: 10px;
			border: none;
			font-family: inherit;
			font-size: 16px;
			margin-bottom: 15px;
			border: 1px solid #333;
		}

		.popup-window button {
			width: 100%;
			padding: 10px;
			border: none;
			border-radius: 5px;
			background: #F42362;
			color: #000;
			cursor: pointer;
			font-family: inherit;
			font-size: 16px;
			font-weight: bold;
			text-transform: uppercase;
			margin-top: 15px;
			border-radius: 20px;
		}

		.close-popup {
			position: absolute;
			right: 10px;
			top: 5px;
			width: 27px;
			height: 27px;
			background-color: #fff;
			cursor: pointer;
		}

		.close-popup:before {
			content: "";
			background: #333;
			width: 20px;
			height: 1px;
			position: absolute;
			top: 13px;
			left: 4px;
			transform: rotate(-45deg);
		}

		.close-popup:after {
			content: "";
			background: #333;
			width: 20px;
			height: 1px;
			position: absolute;
			top: 13px;
			left: 4px;
			transform: rotate(45deg);
		}
	</style>

	<script>
		$(document).ready(function () {

			$('.feedback').click(function () {
				$('.popup-window').show();
			});
			$('.close-popup').click(function () {
				$('.popup-window').hide();
			});
		});
	</script>

<script type="text/javascript" src="https://cdn.ldrock.com/validator.js"></script>
<script type="text/javascript">
    LeadrockValidator.init({
        geo: {
            iso_code: 'ES'
        }
    });
</script>
</body></html>